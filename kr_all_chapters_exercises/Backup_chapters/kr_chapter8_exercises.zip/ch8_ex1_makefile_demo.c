#include <stdio.h>

/*
 * ch8_ex1_makefile_demo.c
 * Exercise: Simple program often used as Makefile target
 */
int main(void) {
    puts("Makefile demo program");
    return 0;
}
