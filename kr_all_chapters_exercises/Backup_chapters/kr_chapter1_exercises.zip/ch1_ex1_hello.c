#include <stdio.h>

/*
 * ch1_ex1_hello.c
 * Exercise 1: Print "Hello, World!" on screen
 */
int main(void)
{
    printf("Hello, World!\n");
    return 0;
}
